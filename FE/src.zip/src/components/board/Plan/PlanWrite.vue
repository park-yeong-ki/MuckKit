<template>
    <div>
        <b-row>
            <b-col cols="2">
                <plan-attraction-list-vue/>
            </b-col>
            <b-col cols="2">
                <plan-search-attraction-vue/>
            </b-col>
            <b-col cols="8">
                <plan-map-vue/>
            </b-col>
        </b-row>
    </div>
</template>

<script>
import PlanAttractionListVue from "./plan-item/PlanAttractionList.vue";
import PlanMapVue from "./plan-item/PlanMap.vue";
import PlanSearchAttractionVue from "./plan-item/PlanSearchAttraction.vue";

export default {
    components: {
        PlanAttractionListVue,
        PlanMapVue,
        PlanSearchAttractionVue
    },
    data() {
        return {
            attraction: {},
        };
    },
    created() {
        this.$store.dispatch("removeAllAttraction");
    },
    methods: {
    },
};
</script>

<style scoped></style>