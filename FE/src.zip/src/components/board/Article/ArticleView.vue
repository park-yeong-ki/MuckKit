<template>
  <div class="container">
    <main class="mb-4">
      <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
          <div class="container List-container">
            <div class="row">
              <div class="col-1 align-self-center ml-3">
                <b-avatar
                  class="align-self-center"
                  src="https://placekitten.com/300/300"
                  size="4rem"
                ></b-avatar>
              </div>
              <div class="col">
                <div class="row mt-1 header">
                  <div class="col text-left" style="word-break: break-all">
                    <h2>{{ article.articleTitle }}</h2>
                  </div>
                </div>
                <div class="row mt-1 header">
                  <div class="col text-left" style="word-break: break-all; font-size: 20px">
                    {{ article.articleWriter }}
                  </div>
                </div>
              </div>
            </div>
            <div class="row mt-3 header">
              <div
                class="col text-left ml-3"
                style="word-break: break-all; font-size: 20px; color: silver"
              >
                {{ article.createdTime.substr(0, 10) }} | 조회수 {{ article.hit }}
              </div>
              <div class="col text-right mr-3" style="word-break: break-all; font-size: 20px">
                좋아요 {{ article.articleHeart }}
              </div>
            </div>
            <hr />
            <div class="board-container">
              <div class="row my-4">
                <b-carousel
                  id="carousel-1"
                  :interval="4000"
                  controls
                  indicators
                  background="#ababab"
                  img-width="1024"
                  img-height="480"
                  style="text-shadow: 1px 1px 2px #333"
                  class="ml-2"
                >
                  <div v-for="(imgs, idx) in imagesAddr" :key="idx">
                    <b-carousel-slide :img-src="imgs" style="width: 1024px; height: 480px">
                      <!-- <img src="imgs" class="img-fluid" style="width: 1024px; height: 480px"/> -->
                    </b-carousel-slide>
                  </div>
                </b-carousel>
              </div>
              <div class="content row my-4 ml-3" style="word-break: break-all">
                {{ article.articleContent }}
              </div>

              <div
                class="p-2 align-items-center"
                style="border: 1px solid silver; border-radius: 5px"
              >
                <div v-for="(att, idx) in attractions" :key="idx">
                  <div class="row align-items-center p-3">
                    <div class="col-1">
                      <!-- <input class="form-check-input" type="checkbox" :value="att.title" /> -->
                      <b-form-checkbox :value="att.title" v-model="wantAddList"> </b-form-checkbox>
                    </div>
                    <div class="col-3 border-right mt-1 mb-1">
                      {{ att.title }}
                    </div>

                    <div class="col-8">{{ att.addr1 }}</div>
                    <!-- <div class="col-8">
                      <label class="form-check-label" for="flexCheckDefault">
                        {{ att.addr1 }}
                      </label>
                    </div> -->
                  </div>
                </div>
              </div>
            </div>
            <div class="mt-5">
              <h5 class="text-left">댓글</h5>
              <div class="mb-3 mt-3">
                <b-input-group>
                  <b-form-textarea
                    class="btn btn-outline-light text-left"
                    type="text"
                    style="border-color: orange"
                    placeholder="댓글을 남겨보세요"
                    v-model="comContent"
                    rows="s"
                  ></b-form-textarea>
                  <b-input-group-append>
                    <b-button
                      id="btnArea"
                      class="btn btn-outline-light btn-lg"
                      style="background-color: orange; border-color: orange"
                      size="sm"
                      v-on:click="addComm()"
                      >등록</b-button
                    >
                  </b-input-group-append>
                </b-input-group>
              </div>
              <div v-for="(comment, idx) in article.comments" :key="idx" :com="comment">
                <div class="border-bottom p-3">
                  <div class="row mt-1 header">
                    <b-avatar
                      class="align-self-center"
                      src="https://placekitten.com/300/300"
                      size="3rem"
                    ></b-avatar>
                    <div class="col text-left" style="word-break: break-all">
                      <h4>{{ comment.commentWriter }}</h4>
                      {{ comment.createdTime }}
                    </div>
                    <div
                      class="col text-right"
                      style="word-break: break-all"
                      v-on:click="remove(comment.commentId)"
                      :v-if="getMemberId === comment.commentWriter"
                    >
                      삭제
                    </div>
                  </div>
                  <div class="row mt-3 header">
                    <div class="col text-left" style="word-break: break-all">
                      {{ comment.content }}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="board-footer">
              <router-link :to="{ name: 'articlelist' }"
                ><b-button
                  id="btnArea"
                  class="btn btn-lg mt-3"
                  style="background-color: orange; border-color: orange"
                  >목록으로</b-button
                ></router-link
              >
              <!-- <router-link :to="{ name: 'articlemodify', params }"
                ><b-button
                  id="btnArea"
                  class="btn btn-lg mt-3 ml-3"
                  @click="movePage"
                  style="background-color: orange; border-color: orange"
                  :v-if="getMemberId === article.articleWriter"
                  >수정하기</b-button
                ></router-link
              > -->
              <b-button
                id="btnArea"
                class="btn btn-lg mt-3 ml-3"
                @click="movePage"
                style="background-color: orange; border-color: orange"
                :v-if="getMemberId === article.articleWriter"
                >수정하기</b-button
              >
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
import http from "@/api/http";
// import ArticleComment from "./ArticleComment.vue";

export default {
  components: {
    // ArticleComment,
  },
  data() {
    return {
      uploadimageurl: [],
      imagecnt: 0,
      article: {},
      attractions: {},
      comContent: "",
      comArticleId: "",
      images: [],
      imagesAddr: [],
      writer: this.$store.getters.getMemberId,
      wantAddList: [],
    };
  },
  mounted() {
    http.get(`/article/view/${this.$route.params.id}`).then((resp) => {
      this.article = resp.data;
      this.attractions = resp.data.plan.attractions;
      this.images = resp.data.plan.attractions;

      for (let i = 0; i < this.images.length; i++) {
        if (this.images[i].first_image) this.imagesAddr.push(this.images[i].first_image);
      }
    });
  },
  methods: {
    movePage() {
      // this.$router.push({ path: `/notice/view/${this.nt.noticeId}` });
      this.$router.push({ name: "articlemodify", params: { id: this.$route.params.id } });
    },
    remove(iddata) {
      http
        .delete(`/comment/${iddata}`, {
          headers: {
            Authorization: "Bearer " + sessionStorage.getItem("access-token"),
          },
        })
        .then((resp) => {
          console.log(resp);
          http.get(`/article/view/${this.$route.params.id}`).then((resp) => {
            this.article = resp.data;
          });
        })
        .catch((error) => {
          console.log(error);
          console.log(iddata);
        });
    },
    addComm() {
      http
        .post(
          `/comment/write`,
          {
            content: this.comContent,
            commentWriter: this.$store.getters.getMemberId,
            articleId: this.$route.params.id,
          },
          {
            headers: {
              Authorization: "Bearer " + sessionStorage.getItem("access-token"),
            },
          }
        )
        .then((resp) => {
          console.log(resp);
          http.get(`/article/view/${this.$route.params.id}`).then((resp) => {
            this.article = resp.data;
          });
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
  computed: {
    memberName() {
      return this.$store.getters.getMemberName;
    },
    memberId() {
      return this.$store.getters.getMemberId;
    },
  },
};
</script>

<style scoped></style>
